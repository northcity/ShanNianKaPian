//
//  LZBaseNavigationController.h
//  LZAccount
//
//  Created by Artron_LQQ on 16/5/30.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LZBaseNavigationController : UINavigationController

@end
