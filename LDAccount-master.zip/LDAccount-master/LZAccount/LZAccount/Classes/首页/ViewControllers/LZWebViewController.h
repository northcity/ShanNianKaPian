//
//  LZWebViewController.h
//  LZAccount
//
//  Created by Artron_LQQ on 16/9/21.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import "LZBaseViewController.h"

@interface LZWebViewController : LZBaseViewController

@property (nonatomic,copy)NSString *urlString;
@end
