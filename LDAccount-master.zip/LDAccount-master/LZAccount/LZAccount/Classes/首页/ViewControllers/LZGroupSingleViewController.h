//
//  LZGroupSingleViewController.h
//  LZAccount
//
//  Created by Artron_LQQ on 2016/10/24.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import "LZBaseViewController.h"
#import "LZGroupModel.h"

@interface LZGroupSingleViewController : LZBaseViewController

@property (nonatomic, strong) LZGroupModel *groupModel;
@end
