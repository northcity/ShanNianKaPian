//
//  LZAboutusViewController.h
//  LZAccount
//
//  Created by Artron_LQQ on 16/6/1.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import "LZBaseViewController.h"

@interface LZAboutusViewController : LZBaseViewController

@end
