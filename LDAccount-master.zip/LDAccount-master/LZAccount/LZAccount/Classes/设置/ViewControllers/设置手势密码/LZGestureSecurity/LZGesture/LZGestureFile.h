
//
//  LZGestureFile.h
//  LZGestureSecurity
//
//  Created by Artron_LQQ on 2016/10/17.
//  Copyright © 2016年 Artup. All rights reserved.
//

#ifndef LZGestureFile_h
#define LZGestureFile_h

// 保存用户是否开启手势解锁的状态
#define kLZGestureEnableByUserKey  @"LZGestureEnableByUserKey"

// 保存 用户设置的手势密码
#define  kLZGesturePsw @"LZGesturePswIsSectted"
#endif /* LZGestureFile_h */
