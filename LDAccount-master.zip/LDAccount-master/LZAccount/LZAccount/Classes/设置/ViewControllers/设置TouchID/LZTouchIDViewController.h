//
//  LZTouchIDViewController.h
//  LZAccount
//
//  Created by Artron_LQQ on 2016/10/19.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import "LZBaseViewController.h"

@interface LZTouchIDViewController : LZBaseViewController

@end
