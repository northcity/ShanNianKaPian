//
//  LZAllViewController.h
//  LZAccount
//
//  Created by Artron_LQQ on 2016/12/16.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import "LZBaseViewController.h"

@interface LZAllViewController : LZBaseViewController

@end
