//
//  LZGroupModel.h
//  LZAccount
//
//  Created by Artron_LQQ on 16/6/3.
//  Copyright © 2016年 Artup. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LZGroupModel : NSObject

@property (copy, nonatomic) NSString *groupName;
@property (copy, nonatomic) NSString *identifier;
@end
