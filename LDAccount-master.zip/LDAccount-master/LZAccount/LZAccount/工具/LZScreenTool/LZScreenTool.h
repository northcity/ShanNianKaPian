//
//  LZScreenTool.h
//  LZAccount
//
//  Created by Artron_LQQ on 2016/10/21.
//  Copyright © 2016年 Artup. All rights reserved.
//
// 锁屏管理工具

#import <Foundation/Foundation.h>

@interface LZScreenTool : NSObject

@end
